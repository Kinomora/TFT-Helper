package no.stelar7.api.r4j.pojo.lol.league;

import java.util.ArrayList;

public class LeagueEntryList extends ArrayList<LeagueEntry>
{
}
