package no.stelar7.api.r4j.pojo.lol.clash;

import java.util.ArrayList;

public class ClashTournamentList extends ArrayList<ClashTournament>
{
}
