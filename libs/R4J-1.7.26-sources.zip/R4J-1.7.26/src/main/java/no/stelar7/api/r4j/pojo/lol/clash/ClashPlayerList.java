package no.stelar7.api.r4j.pojo.lol.clash;

import java.util.*;

public class ClashPlayerList extends ArrayList<ClashPlayer>
{
}
