package no.stelar7.api.r4j.basic.exceptions;

public class APIServerEndpointMissmatchException extends RuntimeException
{
    
    public APIServerEndpointMissmatchException(final String string)
    {
        super(string);
    }
    
}
