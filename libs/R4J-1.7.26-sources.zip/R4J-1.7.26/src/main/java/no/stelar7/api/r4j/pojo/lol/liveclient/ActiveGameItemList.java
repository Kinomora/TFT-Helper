package no.stelar7.api.r4j.pojo.lol.liveclient;

import java.util.ArrayList;

public class ActiveGameItemList extends ArrayList<ActiveGameItem>
{
}
