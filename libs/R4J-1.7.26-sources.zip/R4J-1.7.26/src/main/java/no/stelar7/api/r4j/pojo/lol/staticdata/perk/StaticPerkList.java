package no.stelar7.api.r4j.pojo.lol.staticdata.perk;

import java.util.ArrayList;

public class StaticPerkList extends ArrayList<StaticPerk>
{
}
