package no.stelar7.api.r4j.basic.utils;

import java.util.HashMap;

public class BooleanMap extends HashMap<String, Boolean>
{
}
