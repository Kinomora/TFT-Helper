package no.stelar7.api.r4j.basic.constants.types;

public interface RealmSpesificEnum
{
    String getRealmValue();
}