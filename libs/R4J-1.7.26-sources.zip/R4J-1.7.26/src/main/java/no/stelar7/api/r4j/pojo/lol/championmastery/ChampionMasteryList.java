package no.stelar7.api.r4j.pojo.lol.championmastery;

import no.stelar7.api.r4j.pojo.lol.championmastery.ChampionMastery;

import java.util.ArrayList;

public class ChampionMasteryList extends ArrayList<ChampionMastery>
{
}
