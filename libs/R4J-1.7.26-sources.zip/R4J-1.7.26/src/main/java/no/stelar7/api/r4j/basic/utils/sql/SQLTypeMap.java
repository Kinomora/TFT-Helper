package no.stelar7.api.r4j.basic.utils.sql;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface SQLTypeMap
{

}
