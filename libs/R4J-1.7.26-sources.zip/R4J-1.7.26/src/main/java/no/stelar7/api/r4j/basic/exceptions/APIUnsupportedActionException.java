package no.stelar7.api.r4j.basic.exceptions;

public class APIUnsupportedActionException extends RuntimeException
{
    
    public APIUnsupportedActionException(final String data)
    {
        super(data);
    }
    
}
