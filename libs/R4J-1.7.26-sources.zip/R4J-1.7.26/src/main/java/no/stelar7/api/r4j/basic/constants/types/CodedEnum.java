package no.stelar7.api.r4j.basic.constants.types;

import java.lang.reflect.Type;
import java.util.Optional;

public interface CodedEnum<T>
{
    Optional<T> getFromCode(final String type);
    
    static Object printError(Type type, String value)
    {
        System.err.format("The enum %s is missing the type %s!%nPlease make sure you have the latest version of the library!%nIf you do, send this message to the maintainer of the API.", type.getTypeName(), value);
        return null;
    }
    
    String prettyName();
    
    default String commonName()
    {
        return prettyName();
    }
}
