package no.stelar7.api.r4j.basic.utils;

import java.util.ArrayList;

public class LongList extends ArrayList<Long>
{
}
